# OOP-Ex5
A world simulator.
